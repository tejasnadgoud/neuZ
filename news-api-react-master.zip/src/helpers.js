export function findFlag(flag) {
  return `http://www.geonames.org/flags/x/${flag}.gif`;
}
